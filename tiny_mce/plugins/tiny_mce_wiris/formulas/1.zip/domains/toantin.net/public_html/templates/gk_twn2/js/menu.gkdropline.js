jQuery(document).ready(function() {
	var main = jQuery('#gkDropMain');
	var sub = jQuery('#gkDropSub');
	
	if(main) {
		var submenus = jQuery('#gkSubmenu').find('#gkDropSub > ul');
		var mainmenus = jQuery('#gkDropMain').find('li');
		var currentsub = null;
		
		mainmenus.each(function(i, el) {
				if(el.hasClass('active')){
					currentsub = submenus[i];
					jQuery(currentsub).css('left', 'auto');
					jQuery(currentsub).attr('class', 'active');
				}
	});
		
		main.find('li').each(function(i, el) {
			jQuery(el).mouseenter(function() {
				if(currentsub) {
					jQuery(currentsub).css('left', '-999em'); 
					jQuery(submenus).attr('class', '');
				}
                
				currentsub = submenus[i];
				jQuery(currentsub).css('left', 'auto');
				jQuery(currentsub).attr('class', 'active');
			});
		});
	}
});  