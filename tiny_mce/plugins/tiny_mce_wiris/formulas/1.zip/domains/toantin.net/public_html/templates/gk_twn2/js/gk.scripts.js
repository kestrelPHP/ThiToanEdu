/**
 * jQuery Cookie plugin
 *
 * Copyright (c) 2010 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 */
jQuery.noConflict();
jQuery.cookie = function (key, value, options) {

    // key and at least value given, set cookie...
    if (arguments.length > 1 && String(value) !== "[object Object]") {
        options = jQuery.extend({}, options);

        if (value === null || value === undefined) {
            options.expires = -1;
        }

        if (typeof options.expires === 'number') {
            var days = options.expires, t = options.expires = new Date();
            t.setDate(t.getDate() + days);
        }

        value = String(value);

        return (document.cookie = [
            encodeURIComponent(key), '=',
            options.raw ? value : encodeURIComponent(value),
            options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
            options.path ? '; path=' + options.path : '',
            options.domain ? '; domain=' + options.domain : '',
            options.secure ? '; secure' : ''
        ].join(''));
    }

    // key and possibly options given, get cookie...
    options = value || {};
    var result, decode = options.raw ? function (s) { return s; } : decodeURIComponent;
    return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null;
};


/**
 *
 * Template scripts
 *
 **/
jQuery(document).ready(function() {	// style area

	// style area
	if(jQuery('#gkStyleArea')){
		jQuery('#gkStyleArea').find('a').each(function(i, element){
			jQuery(element).click(function(e){
	            e.preventDefault();
	            e.stopPropagation();
				changeStyle(i+1);
			});
		});
	}
	
	// font-size switcher
	if(jQuery('#gkTools') && jQuery('#gkComponentWrap')) {
		var current_fs = 100;
		
		jQuery('#gkMainbody').css('font-size', current_fs+"%");
		
		jQuery('#gkToolsInc').click(function(e){ 
			e.stopPropagation();
			e.preventDefault(); 
			if(current_fs < 150) {  
				jQuery('#gkMainbody').animate({ 'font-size': (current_fs + 10) + "%"}, 200); 
				current_fs += 10; 
			} 
		});
		jQuery('#gkToolsReset').click(function(e){ 
			e.stopPropagation();
			e.preventDefault(); 
			jQuery('#gkMainbody').animate({ 'font-size' : "100%"}, 200); 
			current_fs = 100; 
		});
		jQuery('#gkToolsDec').click(function(e){ 
			e.stopPropagation();
			e.preventDefault(); 
			if(current_fs > 70) { 
				jQuery('#gkMainbody').animate({ 'font-size': (current_fs - 10) + "%"}, 200); 
				current_fs -= 10; 
			} 
		});
	}
	
	// K2 font-size switcher fix
	if(jQuery('#fontIncrease') && jQuery('.itemIntroText')) {
		jQuery('#fontIncrease').click(function() {
			jQuery('.itemIntroText').attr('class', 'itemIntroText largerFontSize');
		});
		
		jQuery('#fontDecrease').click( function() {
			jQuery('.itemIntroText').attr('class', 'itemIntroText smallerFontSize');
		});
	}
	
	if(jQuery('#system-message-container a.close')){
		  jQuery('#system-message-container').find('a.close').each(function(i, element){
		  		jQuery('#system-message-container').css({'display' : 'block'});	
	           jQuery(element).click(function(e){
	           		e.preventDefault();
	           		e.stopPropagation();
	                jQuery(element).parent().fadeOut();
	                (function() {
	                     jQuery(element).parent().parent().css({'display': 'none'});
	                }).delay(500);
	           });
	      });
	 } 
	 
	// login popup
	// login popup
	if(jQuery('#gkPopupLogin') || jQuery('#gkPopupRegister')) {
		var popup_overlay = jQuery('#gkPopupOverlay');
		popup_overlay.css({'display': 'block'});
		popup_overlay.css({'display':'none'});
		
		jQuery('#gkPopupLogin').css({'display': 'block', 'opacity': 0, 'height' : 0});
		jQuery('#gkPopupRegister').css({'display': 'block', 'opacity': 0, 'height' : 0});
		var opened_popup = null;
		var popup_login = null;
		var popup_login_h = null;
		var popup_register = null;
		var popup_register_h = null;
				
		if(jQuery('#gkPopupLogin')) {
			popup_login = jQuery('#gkPopupLogin');
			popup_login.css('display', 'block');
			popup_login_h = popup_login.find('.gkPopupWrap').outerHeight();
			 
			jQuery('#btnLogin').click( function(e) {
				e.preventDefault();
				e.stopPropagation();
				popup_overlay.fadeIn('slow');
				//popup_login.css({'opacity':1, 'height': popup_login_h});
				popup_login.animate({'opacity':1, 'height': popup_login_h},200, 'swing');
				opened_popup = 'login';
				
				(function() {
					if(jQuery('#modlgn-username')) {
						jQuery('#modlgn-username').focus();
					}
				}).delay(600);
			});
		}
		
		if(jQuery('#gkPopupRegister')) {
			popup_register = jQuery('#gkPopupRegister');
			popup_register.css('display', 'block');
			popup_register_h = popup_register.find('.gkPopupWrap').outerHeight();
			 
			jQuery('#btnRegister').click( function(e) {
			
				showGKRecaptcha('gk_recaptcha',  'submit_1', 'recaptcha_required_1');
				showGKRecaptcha('gk_recaptcha',  'submit_1', 'recaptcha_required_1');
				
				e.preventDefault();
				e.stopPropagation();
				popup_overlay.fadeIn('slow');
				//popup_login.css({'opacity':1, 'height': popup_login_h});
				popup_register.animate({'opacity':1, 'height': popup_register_h},200, 'swing');
				opened_popup = 'register';
				
				(function() {
					if(jQuery('#modlgn-username')) {
						jQuery('#modlgn-username').focus();
					}
				}).delay(600);
			});
		}
		
		
		popup_overlay.click( function() {
			if(opened_popup == 'login')	{
				popup_overlay.fadeOut('slow');
				popup_login.css({
					'opacity' : 0,
					'height' : 0
				});
			}
			if(opened_popup == 'register')	{
				popup_overlay.fadeOut('slow');
				popup_register.css({
					'opacity' : 0,
					'height' : 0
				});
			}
		});
	}
	// nsp header suffix improvement ;)
	if(jQuery('div.header')[0] && jQuery(jQuery('div.header')[0]).find('.nspHeader')) {
		jQuery('div.header').each(function(i, mod) {
			var headers = jQuery(mod).find('.nspHeader');
			headers.each(function(i, elm) {
				elm = jQuery(elm);
				if(elm.parent().find('p.nspInfo')) {
					elm.append(elm.parent().find('p.nspInfo'));
				}
				
				if(elm.parent().find('p.nspText')) {
					elm.append(elm.parent().find('p.nspText'));
				}
			});
		});
	}
});

// Function to change styles
function changeStyle(style){
	var file1 = $GK_TMPL_URL+'/css/style'+style+'.css';
	var file2 = $GK_TMPL_URL+'/css/typography.style'+style+'.css';
	jQuery('head').append('<link rel="stylesheet" href="'+file1+'" type="text/css" />');
	jQuery('head').append('<link rel="stylesheet" href="'+file2+'" type="text/css" />');
	jQuery.cookie('gk_twn2_j30_style', style, { expires: 365, path: '/' });
}